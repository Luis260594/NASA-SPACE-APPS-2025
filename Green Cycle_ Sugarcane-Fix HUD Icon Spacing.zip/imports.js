

import { createNoise2D } from "simplex-noise";
export { createNoise2D };

